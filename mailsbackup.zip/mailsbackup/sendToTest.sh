cp ./* ~/developer_projects/test_projects/mailsbackup/
