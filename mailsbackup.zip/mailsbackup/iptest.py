import ipaddress
__author__ = 'earch'

p = ipaddress
print('hola')