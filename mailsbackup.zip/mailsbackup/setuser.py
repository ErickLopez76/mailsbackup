import confdata

a = confdata.mailsbackup_crypt
a.create_user()
