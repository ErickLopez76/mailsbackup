#Create connection with firebird
__author__ = 'ErickLopez76'
import fdb


#cnx = fdb.connect()